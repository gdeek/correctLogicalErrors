//Program to create matrix
//2018503064
#include<stdio.h>
#include<malloc.h>
void main()
{
	int *a, **b, n,k,i,j;
	printf("Enter the size of 1st array:");
	scanf("%d",&n);
	a=(int *)malloc(sizeof(int)*n);
	printf("Enter the values of a:\n");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	printf("\nEnter the value of k:");
	scanf("%d",&k);
	b=(int **)malloc(sizeof(int *)*n);
	for(i=0;i<n;i++)
		b[i]=(int *)malloc(sizeof(int)*k);
	for(i=0;i<n;i++)
		for(j=0;j<k;j++)
			b[i][j]=a[j]*(i+1);
	printf("\n\nThe matrix b is:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<k;j++)
			printf("%5d",b[i][j]);
		printf("\n");
	}
}
