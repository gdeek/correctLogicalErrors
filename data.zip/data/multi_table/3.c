//Vinayaka Murthy Vijay
//2018503068

#include<stdio.h>
#include<malloc.h>

void main()
{
	int A[100],n,k,i,j,l,o=0;
	printf("Enter Array size:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&A[i]);
	printf("Enter k:");
	scanf("%d",&k);
	int **m;
	m=(int **)malloc(k*sizeof(int *));
	for(i=0;i<k;i++)
	{
		m[i]=(int *)malloc(n*sizeof(int));	
	}
	for(i=0;i<k;i++)
	{
		m[i][0]=A[i];
	}

	for(i=1;i<n;i++)
	{
		l=0;
		for(j=0;j<k;j++)
			m[j][i]=(o+2)*m[l++][0];
		o++;
	}
	printf("\n");
	printf("\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<k;j++)
			printf("%d\t",m[i][j]);
		printf("\n");
	}
}
