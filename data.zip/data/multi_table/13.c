//2018503072
#include<stdio.h>
#include<stdlib.h>
typedef struct{ int **val;int nR;int nC;}matrix;
int main()
{
	int *a,n,k,i,j;
	matrix m;
	printf("\n enter the value of n");
	scanf("%d",&n);
	a=(int *)malloc(sizeof(int)*n);
	for(i=0;i<n;i++)
	{
		a[i]=rand()%10;
		printf("%d\t",a[i]);
	}
	printf("\n enter the value of k");
	scanf("%d",&k);
	m.nR=n;
	m.nC=k;
	m.val=(int **)malloc(sizeof(int *)*m.nR);
	for(i=0;i<m.nR;i++)
		m.val[i]=(int *)malloc(sizeof(int)*m.nC);
	for(i=0;i<m.nR;i++)
	{
		k=1;
		for(j=0;j<m.nC;j++)
		{
			m.val[i][j]=a[i]*k;
			k++;
		}
	}
	printf("\n the matrix is\n");
	for(i=0;i<m.nR;i++)
	{
	
		for(j=0;j<m.nC;j++)
		{
			printf("%d\t",m.val[i][j]);
		
		}
		printf("\n");
	}
	
}
	
