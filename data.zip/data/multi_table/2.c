//M.DINESH PRABHU-2018503518
//Reading an array and filling an matrix
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h> 
int main()
{
int **a,*b,i,j,k,n,s;
printf("\nEnter the number of integers in the array : ");
scanf("%d",&n);
b=(int *)malloc(sizeof(int)*n);
printf("\nThe array is : ");
for(i=0;i<n;i++)
{
	*(b+i)=rand()%10;
	printf("%3d",*(b+i));
}
printf("\nEnter the number of columns in the matrix : ");
scanf("%d",&k);
a=(int **)malloc(sizeof(int *)*n);
for(i=0;i<n;i++)
	*(a+i)=(int *)malloc(sizeof(int)*k);
for(i=0;i<n;i++)
{
	s=1;
	for(j=0;j<k;j++)
	{
			*(*(a+i)+j)=(s++) * (*(b+i)); 
	}
}
printf("\nThe array is : \n\n");
for(i=0;i<n;i++)
{
	for(j=0;j<k;j++)
		printf("%5d",*(*(a+i)+j));
	printf("\n");
}
printf("\n\n");
return  0;
}
		
