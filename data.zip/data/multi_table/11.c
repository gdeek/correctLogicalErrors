//BALAJI R R
// MATRIX
#include<stdio.h>
#include<malloc.h>
void main()
{
random();
int n,k,**p,i,j,m,l;
printf("Enter the size of the array");
scanf("%d",&n);
p=(int **)malloc(sizeof(int *)*n);
for(i=0;i<n;i++)
p[i]=(int *)malloc(n*sizeof(int));
printf("Enter the 'k' value\n");
scanf("%d",&l);
k=l+1;
printf("The array is\n");
for(i=0;i<n;i++)
{
	for(j=0;j<l;j++)
	{
   	p[i][j]=rand()%10;
	}
}	
for(i=0;i<n;i++)
{
	for(j=0;j<l;j++)
	{
   	printf("%d ",p[i][j]);
	}
	printf("\n");
}	

printf("\n");
for(i=0;i<n;i++)
{
	for(j=0;j<k;j++)
		{
		if(j>0)
		{p[i][j]=p[i][0]*j;
		printf("%d ",p[i][j]);
		}
		}
		printf("\n");
}	
}		 

