#include<stdio.h>
#include<stdlib.h>
int **create(int r,int cl)
{
    int **val,i;
    val=(int**)malloc(sizeof(int*)*r);
    for(i=0;i<r;i++)
    *(val+i)=(int*)malloc(sizeof(int)*cl);
    return val;
}
void sinarr(int **val,int r,int cl)
{
    int i,j;
    printf("enter the single dimensional array %d numbers",r);
    for(i=0;i<r;i++)
    scanf("%d",&(*(*(val+i))));
 }
 void assign(int **val,int r,int cl)
 {
    int i,j,k;
    for(i=0;i<r;i++)
    {
        for(j=0,k=2;j<cl;j++,k++)
        *(*(val+i)+(j+1))=(*(*(val+i)))*k;
    }
 }
 void print(int **val,int r,int cl)
 {
    int i,j;
    for(i=0;i<r;i++)
    {
        for(j=0;j<cl;j++)
        printf("%d\t",*(*(val+i)+j));
        printf("\n\n");
     }
 }
 int main()
 {
    int **arr,n,k;
    printf("enter the range of rows and columns");
    scanf("%d%d",&n,&k);
    arr=create(n,k);
    sinarr(arr,n,k);
    assign(arr,n,k);
    print(arr,n,k);
    return 0;
 }
