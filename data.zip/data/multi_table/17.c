//2018503006
//array
#include<stdio.h>
#include<malloc.h>
typedef struct{int r,c,**vals;}MATRIX;
int main()
{
      int arr[100],n,i,j;
      MATRIX m;
      printf("enter r and c");
      scanf("%d%d",&m.r,&m.c);
      m.vals=(int **)malloc(sizeof(int *)*m.r);
      for(i=0;i<m.r;i++)
         m.vals[i]=(int *)malloc(sizeof(int)*m.c);
      printf("enter the array:");
      for(i=0;i<m.r;i++)
         scanf("%d",&arr[i]);
         for(i=0;i<m.r;i++)
               m.vals[i][0]=arr[i];
        for(j=1;j<m.c;j++)
         for(i=0;i<m.r;i++)
         {
               m.vals[i][j]=(j+1)*(m.vals[i][0]);
         }
         for(i=0;i<m.r;i++)
         {
               for(j=0;j<m.c;j++)
                     printf("%5d",m.vals[i][j]);
               printf("\n");       
          }
          return 0;
   }
