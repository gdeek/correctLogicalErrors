//C.Harini
//Matrix
#include<stdio.h>
#include<malloc.h>
#include<stdlib.h> 
int main()
{
 int n,k,**a,i,j;
 printf("Enter Row & column:");
 scanf("%d%d",&n,&k);
 a=(int**)malloc(sizeof(int*)*n);
 for(i=0;i<n;i++)
 {
  a[i]=(int*)malloc(sizeof(int)*k);
 } 
 for(i=0;i<n;i++)
 {
  a[i][0]=rand()%10;
 }
 for(i=0;i<n;i++)
 {
  for(j=0;j<k;j++)
  {
   a[i][j]=j*a[i][0]+a[i][0];
  }
 }
 for(i=0;i<n;i++)
 {
  for(j=0;j<k;j++)
  {
   printf("\t%d",a[i][j]);
  }
  printf("\n");
 }
 return 0;
} 
   
     
   
 
 
  
 
