#include<stdio.h>
int main()
{
 int a[100][100];
 int i,j,k,r,c,d=1;
 printf("enter the values ");
 scanf("%d%d",&r,&c);
 for(i=0;i<r;i++)
  {for(j=0;j<=0;j++)
   {a[i][j]=rand()%10;printf("%2d",a[i][j]);}printf("\n\n");}
 //for(k=0;k<r;k++)
  for(i=0;i<r;i++)
  {for(j=1;j<c;j++)
    { d++;
      a[i][j]=d*a[i][0];
    }printf("\n\n");d=1;}
 
  for(i=0;i<r;i++)
  {for(j=0;j<c;j++)
  printf("%4d",a[i][j]);printf("\n\n");}
 return 0;
}
