//array

#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

main()
{
	int i,j,n,k,**a;
	printf("Enter n and k : ");
	scanf("%d%d",&n,&k);
	a=(int **)malloc(sizeof(int *)*n);
	for(i=0;i<n;i++)
		(*(a+i))=(int *)malloc(sizeof(int)*k);
	for(i=0;i<n;i++)
		*(*(a+i))=rand()%5;
	
	for(i=0;i<n;i++)
		for(j=1;j<k;j++)
			*(*(a+i)+j)=(j+1)*(*(*(a+i)));
	printf("\nThe new matrix is \n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<k;j++)
			printf("%3d",*(*(a+i)+j));
		printf("\n");
	}
}
