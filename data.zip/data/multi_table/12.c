//2018503038
//Creating a matrix from an array
#include<stdio.h>
#include<malloc.h>
int main()
{
	int n,k,i,j;
	printf("\nEnter the size of the array: ");
	scanf("%d",&n);
	int *a;
	a=(int *)malloc(sizeof(int)*n);
	printf("\nEnter the array: ");
	for(i=0;i<n;i++)
		scanf("%d",a+i);
	printf("\nEnter the second dimension of the matrix: ");
	scanf("%d",&k);
	int **m;
	m=(int **)malloc(sizeof(int *)*n);
	for(i=0;i<n;i++)
		for(j=0;j<k;j++)
			m[i]=(int *)malloc(sizeof(int)*k);
	for(i=0;i<n;i++)
		for(j=0;j<k;j++)
			m[i][j]=a[i]*(j+1);
	printf("\nThe matrix : \n\n");
	for(i=0;i<k;i++)
		printf("\t[%2d]",i+1);
	for(i=0;i<n;i++)
		{
			printf("\n[%2d]",i+1);
			for(j=0;j<k;j++)
				printf("\t%2d",m[i][j]);
		}
	printf("\n\n");
	return 0;
}	
