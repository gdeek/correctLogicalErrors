//2018503056
//n x k matrix

#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>

void main()
{
 int i,j,**mat,*a,n,k,p=0;
 printf("\n enter n\n");
 scanf("%d",&n);
 
 a=(int *)malloc(sizeof(int)*n);
 
 printf("\nenter array \n");
 
 for(i=0;i<n;i++)
 scanf("%d",&*(a+i));
  
 printf("\n enter k\n");
 scanf("%d",&k); 
  
 mat=(int**)malloc(sizeof(int*)*n);
 
  for(i=0;i<10;i++)
  mat[i]=(int*)malloc(sizeof(int)*k);
   
  
  for(i=0;i<k;i++)
  {p++;
    for(j=0;j<n;j++)
     mat[j][i]=p*a[j];  
  }
  
  for(i=0;i<n;i++)
 {
   for(j=0;j<k;j++)
    printf("%5d",mat[i][j]);
    printf("\n\n");
 }
 
 }
    
