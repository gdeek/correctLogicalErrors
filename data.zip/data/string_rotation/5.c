#include<stdio.h>
#include<string.h>
int main()
{
    char str[25],temp=0;
    int i,len,shift,k;
    printf("enter the string\n");
    scanf("%s",str);
    len=strlen(str);
    printf("enter the times of circular shift:");
    scanf("%d",&shift);
    for(k=1;k<=shift;k++)
    {
         temp=str[len-1];
       for(i=1;i<len;i++)
        {
        str[len-i]=str[len-(i+1)];
        }
        str[0]=temp;
        
        
    }
    printf("%s",str);
    return 0;
 }
        
    
    
