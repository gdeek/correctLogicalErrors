//2018503056
//rotating a string by k position

#include<stdio.h>

void main()
{
 int i=0,k,c=0,l,t;
 char a[100];
 
 printf("\n enter the string\n");
 scanf("%s",a);
 
 printf("\n\n");
 
 printf("\n enter k\n");
 scanf("%d",&k);
 
 while(a[i])
 {
  c++;
  i++;
  }
  
  for(l=1;l<=k;l++)
  {
    t=a[c-1];
   for(i=0;i<c-1;i++)
   {
    a[c-i-1]=a[c-i-2];
    }
    a[0]=t;
   }
   
   printf("\n%s",a);
   
   printf("\n\n\n\n");
   
   }
    
    
    
    
 
