//Adarsh
//String
#include<stdio.h>
void rotate(char s[],int k)
{
	int j;
	for (j=1;j<=k;j++)
	{
		int i,tp=s[0],ta;
		for(i=0;s[i]!='\0';i++)
		{
			if (s[i+1]!='\0')
			{
				ta=s[i+1];
				s[i+1]=tp;
				tp=ta;
			}
				else
				{
					s[0]=tp;
				}
		}
	}
}
void main()
{
	char s[50];
	printf("Enter the string to be rotated:");
	scanf("%s",s);
	int k;
	printf("Enter no. of position to be rotated:");
	scanf("%d",&k);
	rotate(s,k);
	printf("\n\tRotated string is: %s\n\n",s);
}
