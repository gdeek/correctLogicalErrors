#include<stdio.h>
int main()
{
  char a[100];
  int h=0,i=0,j=0,k,n;
  printf("\nenter the values\n ");
  scanf("%d",&k);
  printf("\ntype the string\n");
  scanf("%s",a);
  while(a[i]!='\0')
     {h++;i++;}n=(h-k)-1;
  for(i=0;i<h;i++)
    {if(i<k)
  printf("%c",a[n+i+1]);
  else
   {
    printf("%c",a[j]);
    j++;}}
  return 0;
}
    
