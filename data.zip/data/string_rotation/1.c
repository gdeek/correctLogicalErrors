//Program to rotate a string
//2018503064
#include<stdio.h>
#include<malloc.h>
void main()
{
	char *a,temp;
	int n,k,i,j;
	printf("Enter the length of the string:");
	scanf("%d",&n);
	a=(char *)malloc(sizeof(char)*n);
	printf("Enter the string:");
	scanf("%s",a);
	printf("Enter the value of k:");
	scanf("%d",&k);
	for(i=0;i<k;i++)
	{
		temp=a[n-1];
		for(j=n-1;j>=1;j--)
			a[j]=a[j-1];
		a[0]=temp;
		
	}
	printf("\n%s\n",a);
}
