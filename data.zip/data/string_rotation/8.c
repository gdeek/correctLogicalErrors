//Sriram V.S.
//Rotating a string
#include<stdio.h>
void rotateString(char s[],int k)
{
	int j=1;
	for(;j<=k;j++)
	{
		int i,tp=s[0],ta;
		for(i=0;s[i]!='\0';i++)
		{
			if(s[i+1]!='\0')
			{
				ta=s[i+1];
				s[i+1]=tp;
				tp=ta;
			}	
				else 
				{
					s[0]=tp;
				}
		}
	}
}
void main()
{
	char	s[50];
			printf("\n\tEnter a string:");
			scanf("%s",s);
	int		k;
			printf("\n\tEnter the number of positions to be rotated:");
			scanf("%d",&k);
			rotateString(s,k);
			printf("\n\tThe rotated string is %s\n\n",s);
}
