//Vinyaka Murthy Vijay
//2018503068

#include<stdio.h>
#include<string.h>

void main()
{
	int i,n,j;
	char s[100];
	printf("Enter the string:");
	scanf("%s",s);
	printf("Enter move by position:");
	scanf("%d",&n);
	int l=strlen(s);
	for(j=0;j<n;j++)
	{
		for(i=l;i>=1;i--)
		{
			s[i]=s[i-1];
		}
		s[0]=s[l];
		s[l]='\0';
	}
	printf("%s",s);
}
