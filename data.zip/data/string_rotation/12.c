//2018503038
//Rotating a string by k positions
#include<stdio.h>
#include<malloc.h>
int main()
{
	char a[50];
	char b[50];
	int i,k,n=0;
	printf("\nEnter the word: ");
	scanf("%s",a);
	printf("\nEnter the number of positions to be rotated: ");
	scanf("%d",&k);
	if(k==0)
		{
			printf("\nRotated word: %s\n\n",a);
			return 0;
		}
	while(a[n]) n += 1;
	for(i=0;i<n;i++)
		b[i]=a[i];
	for(i=0;i<n;i++)
		{
			if((k+i)<n) a[k+i]=b[i];
			else        a[k+i-n]=b[i];
		}
	printf("\nRotated word : %s\n\n",a);
	return 0;
}
