//Monika shree
//matrix
#include<stdio.h>
#include<malloc.h>
int main()
{
  int **a;
  int n,k;
  int i,j;
  printf("Enter the values of n and k");
  scanf("%d%d",&n,&k);
  a=(int **)malloc(sizeof(int *)*n);
  for(i=0;i<n;i++)
  {
    a[i]=(int *)malloc(sizeof(int)*k);
  }
  printf("Enter the values in the first column");
  for(i=0;i<n;i++)
  {
    scanf("%d",&a[i][0]);
  }
  for(i=0;i<n;i++)
  for(j=0;j<k;j++)
    a[i][j]=j*a[i][0]+a[i][0];
  for(i=0;i<n;i++)
  {
    for(j=0;j<k;j++)
    {
      printf("%d\t",a[i][j]);
    }
    printf("\n");
  }
  return 0;
}
