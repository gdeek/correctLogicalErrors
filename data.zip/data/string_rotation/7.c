//string

#include<stdio.h>
#include<string.h>
#include<malloc.h>

main()
{
	char *s,c;
	int i,k,n,x=1;
	s=(char *)malloc(sizeof(char)*30);
	printf("Enter the string : ");
	scanf("%s",s);
	printf("\nEnter the rotating number : ");
	scanf("%d",&k);	
	n=strlen(s);
	x=n-k;
	while(x>0){
	for(i=0;i<n-1;i++)
	{	
		c=s[i+1];
		s[i+1]=s[i];
		s[i]=c;
	}x--;}
	printf("%s",s);
	printf("\n");
}
