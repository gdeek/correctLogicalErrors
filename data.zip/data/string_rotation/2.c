//M.DINESH PRABHU-2018503518
//Rotating a string by K positions
#include<stdio.h>
#include<malloc.h>
int main()
{
int i,j,k,n;
char *p,c;
p=(char *)malloc(sizeof(char)*30);
printf("\nEnter the string : ");
scanf("%s",p);
printf("\nEnte the number of positions : ");
scanf("%d",&k);
for(n=0;*(p+n)!='\0';n++);
for(i=0;i<k;i++)
{
	c=p[n-1];
	for(j=n-2;j>=0;j--)
	{
		p[j+1]=p[j];
	}
	p[0]=c;
}
printf("\nThe string is : %s\n\n",p);
return 0;
}
